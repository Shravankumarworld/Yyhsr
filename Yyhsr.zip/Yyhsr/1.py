https://youtube.com/shorts/ELriY_Zcw8g?si=g5H4_73467EdaO3Himport os

# Environment variables set karo
os.environ['API_ID'] = '27642354'
os.environ['API_HASH'] = '1626e977b8ca6b942761ede70764619d'
os.environ['BOT_TOKEN'] = '6950142758:AAGMiI5_E4lbKTUaIzLami5t4TMEkGH2Ks8'

# Apne original script ka correct path yaha provide karo
os.system('python3 modules/main.py')